#!/bin/sh
# ------------------
# run environment shell
# ------------------
java  jcall $1 1
# ------------------
